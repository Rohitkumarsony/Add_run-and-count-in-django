from django.db import models
from django.contrib.auth.models import User
from embed_video.fields import EmbedVideoField
from django.conf import settings
from django.utils import timezone


# Create your models here.
class Files(models.Model):
    id=models.AutoField(primary_key=True)
    file=models.FileField(upload_to='')
    uploded_dates=models.DateTimeField(auto_now_add=True)
    
class ADD(models.Model):
    add_id = models.AutoField(primary_key=True)
    add_url = EmbedVideoField()
    uploded_date=models.DateTimeField(auto_now_add=True)
    file_id = models.ForeignKey(Files, on_delete=models.CASCADE)
    
class Viewcounts(models.Model):
    view_id=models.AutoField(primary_key=True)
    view_add_id=models.ForeignKey(Files,on_delete=models.CASCADE)
    count=models.IntegerField()
    created_date=models.DateField(auto_now_add=True)
    view_date=models.DateTimeField(default=timezone.now)
    updated_date=models.DateTimeField(default=timezone.now)
    
class Impression(models.Model):
    imp_id=models.AutoField(primary_key=True)
    imp_add_id=models.ForeignKey(ADD,on_delete=models.CASCADE)
    total_count=models.IntegerField()
    created_date=models.DateField(auto_now_add=True)
    view_date=models.DateTimeField(default=timezone.now)
    updated_date=models.DateTimeField(default=timezone.now)
    
    
    

    
    
