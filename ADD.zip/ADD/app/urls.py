from django.contrib import admin
from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.login,name='login'),
    path('signup/',views.signup,name='signup'),
    path('index/',views.index,name='index'),
    path('display/',views.display,name='display'),
    path('upload/',views.upload,name='upload'),
    path('delete/',views.delete,name='delete'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('Add_count/',views.Add_count,name='Add_count'),
    path('Add_Impression/',views.Add_Impression,name='Add_Impression'),
    # path('ip_address/',views.ip_address,name='ip_address'),
    path('get-location-info/', views.get_location_info, name='get_location_info'),

    # path('okk/',views.okk,name='okk'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
