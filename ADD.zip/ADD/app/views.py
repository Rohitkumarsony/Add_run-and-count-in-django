from django.shortcuts import render,redirect,get_object_or_404, redirect
from django.http import HttpResponse,request,JsonResponse,HttpResponseBadRequest
from .models import Files,ADD,Viewcounts,Impression
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import auth
import geocoder
from geopy.geocoders import Nominatim
from datetime import datetime,date
from .forms import Create,LoginForm



def get_location_info(request):
    g = geocoder.ip('me')
    geolocator = Nominatim(user_agent="geoapi")
    location = geolocator.reverse(g.latlng)
    
    return JsonResponse({
        'address': location.address,
        'latitude': location.latitude,
        'longitude': location.longitude,
        'country': location.raw.get('address').get('country'),
        'district': location.raw.get('address').get('county'),
        'zipcode': location.raw.get('address').get('postcode')
    })


def login(request):
    form =LoginForm()
    if request.method == "POST":
        form=LoginForm(request,request.POST)
        if form.is_valid():
            username=request.POST.get('usernames')
            password=request.POST.get('password')
            user=authenticate(request,username=username,password=password)
            if user is not None:
                auth.login(request, user)
                return redirect('index')
            else:
                return render(request, 'login.html', {'error_message': error_message, 'loginform': form})  
    context = {'loginform': form}
    return render(request, 'login.html', context=context)


def signup(request):
    if request.method == "POST":
        form = Create(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = Create()  # Create a new form instance if it's a GET request
    
    context = {'signup': form}
    return render(request, 'signup.html', context=context)

            

# def ip_address(request):
#     user_ip=request.META.get('HTTP_X_FORWARED_FOR')
#     if user_ip is not None:
#         ip=user_ip.split(',')[0]
#     else:
#         ip=request.META.get('REMOTE_ADDR')
#     return HttpResponse("ip address found{}".format(ip))
        
    


def index(request):
    if request.method == "POST":
        file = request.FILES.get('images')
        add_url = request.POST.get('url')
        if file and add_url:
            data = Files(file=file)
            data.save()  
            add_urls = ADD(add_url=add_url, file_id=data)
            add_urls.save()
            
            return redirect('display')
        else:
            return HttpResponse('data not selected!')
    return render(request, 'index.html')

def display(request):
    img=Files.objects.all()
    add=ADD.objects.all()
    user_ip=request.META.get('HTTP_X_FORWARED_FOR')
    if user_ip is not None:
        ip=user_ip.split(',')[0]
    else:
        ip=request.META.get('REMOTE_ADDR')
    context={
        'img':img,
        'add':add,
        'ip':ip,
      
    }
    return render(request,'display.html',context)


def upload(request):
    return redirect('display')

def delete(request):
    d=Files.objects.all().delete()
    add=ADD.objects.all().delete()
    add_count=Viewcounts.objects.all().delete()
    return redirect('index')


def dashboard(request):
    return redirect('display')


def Add_count(request):
    if request.method == "POST":
        view_add_id = request.POST.get('image_id')
        count = request.POST.get('count')
        today = date.today()
        if view_add_id and count:
            files_instance = get_object_or_404(Files, pk=view_add_id)
            view_count_instance = Viewcounts.objects.filter(view_add_id=files_instance, created_date=today).first()
            if view_count_instance:
                view_count_instance.count += 1 
                view_count_instance.save()
            else:
                view_count_instance = Viewcounts(view_add_id=files_instance, count=count, created_date=today)
                view_count_instance.save()
            
            return redirect('index')

    return HttpResponseBadRequest()  


def Add_Impression(request):
    if request.method == "POST":
        image_id = request.POST.get('image_id')
        count = request.POST.get('count')
        today = date.today()
        if image_id and count:
            add_instance = get_object_or_404(ADD, pk=image_id)
            
            impression_instance = Impression.objects.filter(imp_add_id=add_instance, created_date=today).first()
            if impression_instance:
                impression_instance.total_count += 1  # Update total count
                impression_instance.save()
            else:
                impression_instance = Impression(imp_add_id=add_instance, total_count=count, created_date=today)
                impression_instance.save()
            
            return HttpResponse('Impression added successfully')

    return HttpResponseBadRequest('Invalid request')